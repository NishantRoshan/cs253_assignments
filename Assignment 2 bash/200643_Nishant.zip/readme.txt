In the bash terminal, run the file using ./lab.sh input_file output_file
We need to provide the name of input and output file at the beginning only